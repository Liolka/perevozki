#SXD20|20010|50542|50329|2015.03.31 13:57:04|gfclubne_orisad|0|1|1|
#TA 1gsk_users_companies`1`16384
#EOH

#	TC`1gsk_users_companies`utf8_general_ci	;
CREATE TABLE `1gsk_users_companies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `phone1` varchar(255) NOT NULL,
  `phone2` varchar(255) NOT NULL,
  `phone3` varchar(255) NOT NULL,
  `phone4` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `site` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `count_auto` varchar(128) NOT NULL,
  `count_staff` varchar(128) NOT NULL,
  `main_office` varchar(255) NOT NULL,
  `filials` varchar(255) NOT NULL,
  `terminals` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `1gsk_users_companies_ibfk_1` FOREIGN KEY (`id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`1gsk_users_companies`utf8_general_ci	;
INSERT INTO `1gsk_users_companies` VALUES 
(1,9,'+375 (46) 567 81 82','+375 (46) 567 81 82','+375 (46) 567 81 82','+375 (46) 567 81 82','vanya125@mail.ru','vanya125','vanya125.ru','','2004','54','','Россия, Москва, ул.Лукинская','','','Перевозка автомобилей конструктивно предусмотренными, многоместными прицепными системами – автовозами. Собственный парк автовозов европейского производства, в безупречном техническом состоянии, оборудованных всем необходимым для транспортировки автомобилей любых типов и размеров.')	;
