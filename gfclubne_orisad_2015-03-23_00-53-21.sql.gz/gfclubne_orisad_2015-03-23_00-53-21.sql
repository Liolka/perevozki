#SXD20|20010|50542|50329|2015.03.23 00:53:21|gfclubne_orisad|0|12|98|
#TA 1gsk_bids`11`16384|1gsk_bids_cargoes`13`16384|1gsk_cargoes`13`16384|1gsk_cargoes_categories`11`16384|1gsk_categories`17`16384|1gsk_deals`0`16384|1gsk_migration`2`16384|1gsk_pages`8`16384|1gsk_profiles`11`16384|1gsk_profiles_fields`0`16384|1gsk_users`11`16384|1gsk_users1`1`16384
#EOH

#	TC`1gsk_bids`utf8_general_ci	;
CREATE TABLE `1gsk_bids` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `date_transportation` date NOT NULL,
  `time_transportation` time NOT NULL,
  `date_unknown` tinyint(1) NOT NULL,
  `price` int(11) NOT NULL,
  `loading_town` varchar(255) NOT NULL,
  `loading_address` varchar(255) NOT NULL,
  `add_loading_unloading_town_1` varchar(255) NOT NULL,
  `add_loading_unloading_address_1` varchar(255) NOT NULL,
  `add_loading_unloading_town_2` varchar(255) NOT NULL,
  `add_loading_unloading_address_2` varchar(255) NOT NULL,
  `add_loading_unloading_town_3` varchar(255) NOT NULL,
  `add_loading_unloading_address_3` varchar(255) NOT NULL,
  `unloading_town` varchar(255) NOT NULL,
  `unloading_address` varchar(255) NOT NULL,
  PRIMARY KEY (`bid_id`),
  KEY `published` (`published`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids`utf8_general_ci	;
INSERT INTO `1gsk_bids` VALUES 
(1,9,2,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,11,'qweq','1231','','','','','','','1231','132'),
(11,9,2,'2015-03-19 23:46:07',1,'2015-03-19','23:10:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(12,9,2,'2015-03-20 00:07:24',1,'2015-03-19','13:30:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(13,9,2,'2015-03-20 00:17:11',1,'2015-03-26','12:45:00',0,1121,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(14,9,2,'2015-03-20 00:30:05',1,'2015-03-20','12:45:00',0,1234,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(15,21,2,'2015-03-20 00:38:37',1,'2015-03-28','23:10:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(16,9,2,'2015-03-20 16:07:51',1,'0000-00-00','00:00:00',0,0,'121122','121','','','','','','','1231','21212'),
(17,9,2,'2015-03-20 19:12:52',1,'2015-03-27','16:00:00',0,230000,'Гомель','ул. Советская 10','','','','','','','Гомель','ул. Советская 110'),
(18,9,2,'2015-03-21 00:19:12',1,'2015-03-27','23:10:00',0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(20,9,1,'2015-03-21 23:17:02',1,'2015-03-04','23:10:00',0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(21,9,2,'2015-03-21 23:20:42',1,'2015-03-13','12:45:00',0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21')	;
#	TC`1gsk_bids_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_bids_cargoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bid_cagro` (`bid_id`,`cargo_id`),
  KEY `bid_id` (`bid_id`),
  KEY `cargo_id` (`cargo_id`),
  CONSTRAINT `1gsk_bids_cargoes_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_cargoes_ibfk_2` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_bids_cargoes` VALUES 
(1,12,1),
(2,12,2),
(3,13,3),
(4,13,4),
(5,14,5),
(6,14,6),
(7,15,7),
(8,16,8),
(9,17,9),
(10,18,10),
(11,18,11),
(12,20,12),
(13,21,13)	;
#	TC`1gsk_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes` (
  `cargo_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `weight` float NOT NULL,
  `unit` tinyint(1) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `porters` tinyint(1) NOT NULL,
  `lift_to_floor` tinyint(1) NOT NULL,
  `floor` smallint(2) NOT NULL,
  `length` float NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `volume` float NOT NULL,
  PRIMARY KEY (`cargo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_cargoes` VALUES 
(1,'Мебель мелкая','',12,1,'',1,0,0,0,0,0,0),
(2,'Мебель мелкая','',112,1,'',0,1,0,0,0,0,0),
(3,'Мебель мелкая','dqweqwewq',3454,1,'',0,0,0,0,0,0,0),
(4,'Техника крупная','rfrewewe',332,1,'',0,0,0,0,0,0,0),
(5,'Мебель мелкая, Техника крупная','qwdqweqwe',121,2,'',1,1,0,11,12,12,0),
(6,'Мебель мелкая wwww','sdfadq',112,1,'',0,0,0,0,0,0,0),
(7,'Мебель мелкая, Техника крупная','фвйвцй',121,1,'',1,1,0,0,0,0,0),
(8,'','',0,0,'',0,0,0,0,0,0,0),
(9,'Мебель мелкая','мой коммент к грузу',50,1,'',0,0,0,3,2,5,30),
(10,'Мебель мелкая','12312321',121,1,'',0,0,0,0,0,0,0),
(11,'Техника крупная','312313123',12,1,'',1,0,0,0,0,0,0),
(12,'Мебель мелкая, Техника крупная','',121,1,'',0,0,0,0,0,0,0),
(13,'Мебель мелкая','',0,1,'',0,0,0,0,0,0,0)	;
#	TC`1gsk_cargoes_categories`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cargo_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cargo_category` (`cargo_id`,`category_id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_cargoes_categories_ibfk_1` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_cargoes_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes_categories`utf8_general_ci	;
INSERT INTO `1gsk_cargoes_categories` VALUES 
(1,5,5),
(2,5,6),
(3,6,5),
(4,7,5),
(5,7,6),
(6,9,5),
(7,10,5),
(8,11,6),
(9,12,5),
(10,12,6),
(11,13,5)	;
#	TC`1gsk_categories`utf8_general_ci	;
CREATE TABLE `1gsk_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `level` tinyint(1) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `category_description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `level` (`level`),
  KEY `root` (`root`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8	;
#	TD`1gsk_categories`utf8_general_ci	;
INSERT INTO `1gsk_categories` VALUES 
(1,1,1,34,1,0,'ROOT !!!НЕ УДАЛЯТЬ!!!','','','',''),
(2,1,2,7,2,1,'Мебель и бытовая техника','','','',''),
(3,1,8,13,2,1,'Переезд','','','',''),
(4,1,14,15,2,1,'Перевозка пассажиров','','','',''),
(5,1,3,4,3,2,'Мебель мелкая','','','',''),
(6,1,5,6,3,2,'Техника крупная','','','',''),
(7,1,16,17,2,1,'Продукты питания','','','',''),
(8,1,18,19,2,1,'Вывоз мусора','','','',''),
(9,1,20,21,2,1,'Транспортные средства','','','',''),
(10,1,22,23,2,1,'Строительные грузы и оборудование','','','',''),
(11,1,24,25,2,1,'Наливные грузы','','','',''),
(12,1,26,27,2,1,'Сыпучие грузы','','','',''),
(13,1,28,29,2,1,'Перевозка животных','','','',''),
(14,1,30,31,2,1,'Негабарит','','','',''),
(15,1,32,33,2,1,'Прочие грузы','','','',''),
(16,1,9,10,3,3,'Переезд1','','','',''),
(17,1,11,12,3,3,'Переезд2','','','','')	;
#	TC`1gsk_deals`utf8_general_ci	;
CREATE TABLE `1gsk_deals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `carrier_comment` text NOT NULL,
  `customer_comment` text NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  `rejected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid_id` (`bid_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `1gsk_deals_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_deals_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`1gsk_migration`utf8_general_ci	;
CREATE TABLE `1gsk_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`1gsk_migration`utf8_general_ci	;
INSERT INTO `1gsk_migration` VALUES 
('m000000_000000_base',1423410897),
('m130524_201442_init',1423410904)	;
#	TC`1gsk_pages`utf8_general_ci	;
CREATE TABLE `1gsk_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`1gsk_pages`utf8_general_ci	;
INSERT INTO `1gsk_pages` VALUES 
(2,'Как это работает','kak-eto-rabotaet','Страница &quot;Как это работает&quot;','','',''),
(3,'Гарантии','garantii','Страница &quot;Гарантии&quot;','','',''),
(4,'Контакты','kontakty','стр.&nbsp;Контакты','','',''),
(5,'Помощь грузодателю','pomoshch-gruzodatelyu','стр.&nbsp;Помощь грузодателю','','',''),
(6,'Помощь перевозчику','pomoshch-perevozchiku','стр.&nbsp;Помощь перевозчику','','',''),
(7,'Частые вопросы','chastye-voprosy','стр&nbsp;Частые вопросы','','',''),
(8,'Интернет-магазинам','internet-magazinam','стр.&nbsp;Интернет-магазинам','','',''),
(9,'Система рейтинга','sistema-reitinga','стр.&nbsp;Система рейтинга','','','')	;
#	TC`1gsk_profiles`utf8_general_ci	;
CREATE TABLE `1gsk_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`1gsk_profiles`utf8_general_ci	;
INSERT INTO `1gsk_profiles` VALUES 
(1),
(2),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(21)	;
#	TC`1gsk_profiles_fields`utf8_general_ci	;
CREATE TABLE `1gsk_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` varchar(15) NOT NULL DEFAULT '0',
  `field_size_min` varchar(15) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`1gsk_users`utf8_general_ci	;
CREATE TABLE `1gsk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `user_type` tinyint(1) DEFAULT '0' COMMENT 'грузодатель/перевозчик',
  `user_status` tinyint(1) DEFAULT '0' COMMENT 'юр.лицо / физ.лицо',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`1gsk_users`utf8_general_ci	;
INSERT INTO `1gsk_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','webmaster@example.com','9a24eff8c15a6a141ece27eb6947da0f','2015-02-09 06:19:20','2015-02-14 07:10:45',1,1,0,0),
(2,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@example.com','099f825543f7850cc038b90aaff39fac','2015-02-09 06:19:20','2015-02-10 08:37:16',0,1,0,0),
(9,'alexius','2c216b1ba5e33a27eb6d3df7de7f8c36','aldegtyarev@yandex.ru','d9f2df80ade29aac196fe1dd87468438','2015-02-14 07:54:46','2015-03-23 00:52:09',0,1,2,1),
(10,'user1','b59c67bf196a4758191e42f76670ceba','user1@ya.com','801a9ee13894caf3446fbd5d0a52ef24','2015-03-05 16:33:09','0000-00-00 00:00:00',0,0,1,1),
(11,'user2','b59c67bf196a4758191e42f76670ceba','user2@mail.ru','e26df1ad8500b1365dfae6a83ef63464','2015-03-05 16:35:39','0000-00-00 00:00:00',0,0,2,2),
(12,'user3','b59c67bf196a4758191e42f76670ceba','user3@ya.com','2b2a0767317b6ca6af001e3ae3d02651','2015-03-05 16:39:47','0000-00-00 00:00:00',0,0,2,1),
(13,'user5','b59c67bf196a4758191e42f76670ceba','user5@ya.com','54c05d479a6a38e7a28556c4be78c196','2015-03-05 16:41:30','0000-00-00 00:00:00',0,0,2,2),
(14,'user6','b59c67bf196a4758191e42f76670ceba','user6@mai.ru','01b682485d1cd7adda8832c9ad2baed2','2015-03-05 17:31:44','0000-00-00 00:00:00',0,0,2,1),
(15,'user7','b59c67bf196a4758191e42f76670ceba','user7@ya.com','40f98ac2f1dbec41d2cfcd86ab51da99','2015-03-05 17:37:36','0000-00-00 00:00:00',0,0,1,1),
(16,'user8','b59c67bf196a4758191e42f76670ceba','usr8@meil.ru','829bb32a06bf2487f35cdfba1ed6cfeb','2015-03-05 17:40:22','0000-00-00 00:00:00',0,0,2,2),
(21,'aad','970318d05258ca421c1d5b055442a474','aldegtyarev1980@mail.ru','99c6e34fb57b38b98f0a0886229a4214','2015-03-20 00:38:36','0000-00-00 00:00:00',0,1,1,1)	;
#	TC`1gsk_users1`utf8_unicode_ci	;
CREATE TABLE `1gsk_users1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`1gsk_users1`utf8_unicode_ci	;
INSERT INTO `1gsk_users1` VALUES 
(1,'admin','j-NT1lxHguMH1KQU_DegytBsqo2FTW0u','',\N,'aad@site.com',1,1423427052,1423427052)	;
