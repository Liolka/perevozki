#SXD20|20010|50542|50329|2015.03.25 14:36:44|gfclubne_orisad|0|1|15|
#TA 1gsk_bids`15`16384
#EOH

#	TC`1gsk_bids`utf8_general_ci	;
CREATE TABLE `1gsk_bids` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `date_transportation` date NOT NULL,
  `time_transportation` time NOT NULL,
  `date_unknown` tinyint(1) NOT NULL,
  `quickly` tinyint(1) NOT NULL,
  `price` int(11) NOT NULL,
  `loading_town` varchar(255) NOT NULL,
  `loading_address` varchar(255) NOT NULL,
  `add_loading_unloading_town_1` varchar(255) NOT NULL,
  `add_loading_unloading_address_1` varchar(255) NOT NULL,
  `add_loading_unloading_town_2` varchar(255) NOT NULL,
  `add_loading_unloading_address_2` varchar(255) NOT NULL,
  `add_loading_unloading_town_3` varchar(255) NOT NULL,
  `add_loading_unloading_address_3` varchar(255) NOT NULL,
  `unloading_town` varchar(255) NOT NULL,
  `unloading_address` varchar(255) NOT NULL,
  PRIMARY KEY (`bid_id`),
  KEY `published` (`published`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_bids_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids`utf8_general_ci	;
INSERT INTO `1gsk_bids` VALUES 
(1,9,2,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,0,11,'qweq','1231','','','','','','','1231','132'),
(11,9,2,'2015-03-19 23:46:07',1,'2015-03-19','23:10:00',0,0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(12,9,2,'2015-03-20 00:07:24',1,'2015-03-19','13:30:00',0,0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(13,9,2,'2015-03-20 00:17:11',1,'2015-03-26','12:45:00',0,0,1121,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(14,9,2,'2015-03-20 00:30:05',1,'2015-03-20','12:45:00',0,0,1234,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(15,21,2,'2015-03-20 00:38:37',1,'2015-03-28','23:10:00',0,0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(16,9,2,'2015-03-20 16:07:51',1,'0000-00-00','00:00:00',0,0,0,'121122','121','','','','','','','1231','21212'),
(17,9,2,'2015-03-20 19:12:52',1,'2015-03-27','16:00:00',0,0,230000,'Гомель','ул. Советская 10','','','','','','','Гомель','ул. Советская 110'),
(18,9,2,'2015-03-21 00:19:12',1,'2015-03-27','23:10:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(20,9,2,'2015-03-21 23:17:02',1,'2015-03-04','23:10:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(21,9,2,'2015-03-21 23:20:42',1,'2015-03-13','12:45:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(22,9,2,'2015-03-23 21:50:41',1,'2015-03-25','11:00:00',0,0,250000,'Гомель','Советская 102','','','','','','','Гомель','Джержинского 16'),
(23,9,2,'2015-03-24 00:05:20',1,'2015-03-25','12:45:00',0,1,250000,'Гомель','Советская 102','','','','','','','Гомель','Космонавтов 21'),
(24,9,2,'2015-03-24 00:45:12',1,'2015-03-26','00:00:00',0,1,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(25,9,2,'2015-03-25 00:52:20',1,'2015-04-30','23:10:00',0,1,250000,'Гомель','Советская 102','Гомель','Советская 104','Гомель','Советская 106','Гомель','Пролетарская 14','Гомель','Космонавтов 21')	;
