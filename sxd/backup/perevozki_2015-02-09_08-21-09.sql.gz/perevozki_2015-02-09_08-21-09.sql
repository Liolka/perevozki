#SXD20|20010|50537|50426|2015.02.09 08:21:09|perevozki|0|5|11|
#TA 1gsk_migration`2`16384|1gsk_profiles`3`16384|1gsk_profiles_fields`2`16384|1gsk_users`3`16384|1gsk_users1`1`16384
#EOH

#	TC`1gsk_migration`utf8_general_ci	;
CREATE TABLE `1gsk_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`1gsk_migration`utf8_general_ci	;
INSERT INTO `1gsk_migration` VALUES 
('m000000_000000_base',1423410897),
('m130524_201442_init',1423410904)	;
#	TC`1gsk_profiles`utf8_general_ci	;
CREATE TABLE `1gsk_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`1gsk_profiles`utf8_general_ci	;
INSERT INTO `1gsk_profiles` VALUES 
(1,'Admin','Administrator'),
(2,'Demo','Demo'),
(3,'sdfserwrwer','qwewqeqwewq')	;
#	TC`1gsk_profiles_fields`utf8_general_ci	;
CREATE TABLE `1gsk_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` varchar(15) NOT NULL DEFAULT '0',
  `field_size_min` varchar(15) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`1gsk_profiles_fields`utf8_general_ci	;
INSERT INTO `1gsk_profiles_fields` VALUES 
(1,'lastname','Last Name','VARCHAR','50','3',1,'','','Incorrect Last Name (length between 3 and 50 characters).','','','','',1,3),
(2,'firstname','First Name','VARCHAR','50','3',1,'','','Incorrect First Name (length between 3 and 50 characters).','','','','',0,3)	;
#	TC`1gsk_users`utf8_general_ci	;
CREATE TABLE `1gsk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`1gsk_users`utf8_general_ci	;
INSERT INTO `1gsk_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','webmaster@example.com','9a24eff8c15a6a141ece27eb6947da0f','2015-02-09 07:19:20','0000-00-00 00:00:00',1,1),
(2,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@example.com','099f825543f7850cc038b90aaff39fac','2015-02-09 07:19:20','0000-00-00 00:00:00',0,1),
(3,'aad','f7631fb2f926b43c42308226e97fcec0','aad@ya.com','c0a4f7e1201a47b037aae8725d6dc648','2015-02-09 07:20:41','0000-00-00 00:00:00',0,0)	;
#	TC`1gsk_users1`utf8_unicode_ci	;
CREATE TABLE `1gsk_users1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`1gsk_users1`utf8_unicode_ci	;
INSERT INTO `1gsk_users1` VALUES 
(1,'admin','j-NT1lxHguMH1KQU_DegytBsqo2FTW0u','',\N,'aad@site.com',1,1423427052,1423427052)	;
