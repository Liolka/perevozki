#SXD20|20010|50542|50329|2015.03.30 01:08:21|gfclubne_orisad|0|11|99|
#TA 1gsk_bids`10`16384|1gsk_bids_cargoes`12`16384|1gsk_cargoes`20`16384|1gsk_cargoes_categories`20`16384|1gsk_deals`5`16384|1gsk_deals_posts`5`16384|1gsk_migration`2`16384|1gsk_pages`9`16384|1gsk_profiles`11`16384|1gsk_profiles_fields`0`16384|1gsk_transport`5`16384
#EOH

#	TC`1gsk_bids`utf8_general_ci	;
CREATE TABLE `1gsk_bids` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `date_transportation` date NOT NULL,
  `time_transportation` time NOT NULL,
  `date_unknown` tinyint(1) NOT NULL,
  `quickly` tinyint(1) NOT NULL,
  `price` int(11) NOT NULL,
  `loading_town` varchar(255) NOT NULL,
  `loading_address` varchar(255) NOT NULL,
  `add_loading_unloading_town_1` varchar(255) NOT NULL,
  `add_loading_unloading_address_1` varchar(255) NOT NULL,
  `add_loading_unloading_town_2` varchar(255) NOT NULL,
  `add_loading_unloading_address_2` varchar(255) NOT NULL,
  `add_loading_unloading_town_3` varchar(255) NOT NULL,
  `add_loading_unloading_address_3` varchar(255) NOT NULL,
  `unloading_town` varchar(255) NOT NULL,
  `unloading_address` varchar(255) NOT NULL,
  PRIMARY KEY (`bid_id`),
  KEY `published` (`published`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_bids_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids`utf8_general_ci	;
INSERT INTO `1gsk_bids` VALUES 
(17,9,2,'2015-03-20 19:12:52',1,'2015-03-27','16:00:00',0,0,230000,'Гомель','ул. Советская 10','','','','','','','Гомель','ул. Советская 110'),
(18,9,2,'2015-03-21 00:19:12',1,'2015-03-27','23:10:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(20,9,2,'2015-03-21 23:17:02',1,'2015-03-04','23:10:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(21,9,2,'2015-03-21 23:20:42',1,'2015-03-13','12:45:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(22,9,2,'2015-03-23 21:50:41',1,'2015-03-25','11:00:00',0,0,250000,'Гомель','Советская 102','','','','','','','Гомель','Джержинского 16'),
(23,9,2,'2015-03-24 00:05:20',1,'2015-03-25','12:45:00',0,0,250000,'Гомель','Советская 102','','','','','','','Гомель','Космонавтов 21'),
(24,9,2,'2015-03-24 00:45:12',1,'2015-03-26','00:00:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(25,9,2,'2015-03-25 00:52:20',1,'2015-04-30','23:10:00',0,0,250000,'Гомель','Советская 102','Гомель','Советская 104','Гомель','Советская 106','Гомель','Пролетарская 14','Гомель','Космонавтов 21'),
(26,9,2,'2015-03-29 15:38:06',1,'2015-04-18','12:45:00',0,0,1234,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(27,9,2,'2015-03-30 00:31:21',1,'2015-04-26','11:00:00',0,0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21')	;
#	TC`1gsk_bids_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_bids_cargoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bid_cagro` (`bid_id`,`cargo_id`),
  KEY `bid_id` (`bid_id`),
  KEY `cargo_id` (`cargo_id`),
  CONSTRAINT `1gsk_bids_cargoes_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_cargoes_ibfk_2` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_bids_cargoes` VALUES 
(9,17,9),
(10,18,10),
(11,18,11),
(12,20,12),
(13,21,13),
(14,22,14),
(15,23,15),
(16,24,16),
(17,24,17),
(18,25,18),
(19,26,19),
(20,27,20)	;
#	TC`1gsk_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes` (
  `cargo_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `weight` float NOT NULL,
  `unit` tinyint(1) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `porters` tinyint(1) NOT NULL,
  `lift_to_floor` tinyint(1) NOT NULL,
  `lift` tinyint(1) NOT NULL,
  `floor` smallint(2) NOT NULL,
  `length` float NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `volume` float NOT NULL,
  PRIMARY KEY (`cargo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_cargoes` VALUES 
(1,'Мебель мелкая','',12,1,'',1,0,0,0,0,0,0,0),
(2,'Мебель мелкая','',112,1,'',0,1,0,0,0,0,0,0),
(3,'Мебель мелкая','dqweqwewq',3454,1,'',0,0,0,0,0,0,0,0),
(4,'Техника крупная','rfrewewe',332,1,'',0,0,0,0,0,0,0,0),
(5,'Мебель мелкая, Техника крупная','qwdqweqwe',121,2,'',1,1,0,0,11,12,12,0),
(6,'Мебель мелкая wwww','sdfadq',112,1,'',0,0,0,0,0,0,0,0),
(7,'Мебель мелкая, Техника крупная','фвйвцй',121,1,'',1,1,0,0,0,0,0,0),
(8,'','',0,0,'',0,0,0,0,0,0,0,0),
(9,'Мебель мелкая','мой коммент к грузу',50,1,'',0,0,0,0,3,2,5,30),
(10,'Мебель мелкая','Таким образом постоянное информационно-пропагандистское обеспечение нашей деятельности позволяет оценить значение направлений прогрессивного развития. ',121,1,'',0,0,0,0,2,1,3,6),
(11,'Техника крупная','Повседневная практика показывает, что постоянный количественный рост и сфера нашей активности способствует подготовки и реализации новых предложений.',12,1,'',1,0,0,0,3,3,3,9),
(12,'Мебель мелкая, Техника крупная','',121,1,'',0,0,0,0,0,0,0,0),
(13,'Мебель мелкая','Таким образом постоянное информационно-пропагандистское обеспечение нашей деятельности позволяет оценить значение направлений прогрессивного развития. Повседневная практика показывает, что постоянный количественный рост и сфера нашей активности способствует подготовки и реализации новых предложений. Значимость этих проблем настолько очевидна, что реализация намеченных плановых заданий представляет собой интересный эксперимент проверки существенных финансовых и административных условий. Повседневная практика показывает, что новая модель организационной деятельности представляет собой интересный эксперимент проверки систем массового участия.',0,1,'',0,0,0,0,0,0,0,0),
(14,'Мебель мелкая','Таким образом постоянное информационно-пропагандистское обеспечение нашей деятельности позволяет оценить значение направлений прогрессивного развития. Повседневная практика показывает, что постоянный количественный рост и сфера нашей активности способствует подготовки и реализации новых предложений. Значимость этих проблем настолько очевидна, что реализация намеченных плановых заданий представляет собой интересный эксперимент проверки существенных финансовых и административных условий. Повседневная практика показывает, что новая модель организационной деятельности представляет собой интересный эксперимент проверки систем массового участия.',12,1,'',0,0,0,0,12,3,2,12),
(15,'Мебель мелкая, Техника крупная','Таким образом постоянное информационно-пропагандистское обеспечение нашей деятельности позволяет оценить значение направлений прогрессивного развития. ',121,2,'',1,1,0,0,12,21,11,121),
(16,'Мебель мелкая, Техника крупная','Таким образом постоянное информационно-пропагандистское обеспечение нашей деятельности позволяет оценить значение направлений прогрессивного развития. ',12,1,'',0,1,1,3,0,0,0,0),
(17,'Мебель мелкая','Таким образом постоянное информационно-пропагандистское обеспечение нашей деятельности позволяет оценить значение направлений прогрессивного развития. ',2,2,'',1,1,1,3,0,0,0,0),
(18,'Мебель мелкая, Техника крупная','',121,1,'',0,1,1,5,0,0,0,0),
(19,'Мебель мелкая','',0,1,'',1,0,0,0,0,0,0,0),
(20,'Мебель мелкая','',0,1,'',0,0,0,0,0,0,0,0)	;
#	TC`1gsk_cargoes_categories`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cargo_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cargo_category` (`cargo_id`,`category_id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_cargoes_categories_ibfk_1` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_cargoes_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes_categories`utf8_general_ci	;
INSERT INTO `1gsk_cargoes_categories` VALUES 
(1,5,5),
(2,5,6),
(3,6,5),
(4,7,5),
(5,7,6),
(6,9,5),
(7,10,5),
(8,11,6),
(9,12,5),
(10,12,6),
(11,13,5),
(12,14,5),
(13,15,5),
(14,15,6),
(15,16,5),
(16,16,6),
(17,18,5),
(18,18,6),
(19,19,5),
(20,20,5)	;
#	TC`1gsk_deals`utf8_general_ci	;
CREATE TABLE `1gsk_deals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transport_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `price` int(11) NOT NULL,
  `deal_date` date NOT NULL,
  `deal_time` time NOT NULL,
  `porters` tinyint(1) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  `rejected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid_id` (`bid_id`),
  KEY `user_id` (`user_id`),
  KEY `transport_id` (`transport_id`),
  CONSTRAINT `1gsk_deals_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_deals_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_deals_ibfk_3` FOREIGN KEY (`transport_id`) REFERENCES `1gsk_transport` (`transport_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`1gsk_deals`utf8_general_ci	;
INSERT INTO `1gsk_deals` VALUES 
(5,25,9,10,'2015-03-29 10:11:33','2015-03-29 23:31:24',123000,'2015-05-29','20:30:00',1,'r332\r\nwerwrq3\r\ne23e2213213',0,0),
(6,25,9,6,'2015-03-29 10:12:30','2015-03-29 23:34:33',65000,'2015-05-08','18:30:00',1,'выполним в срок',1,0),
(7,25,9,11,'2015-03-29 11:16:05','2015-03-29 23:18:25',145000,'2015-04-09','14:30:00',1,'Оперативно',0,1),
(8,24,9,10,'2015-03-29 12:33:33','2015-03-29 18:34:42',50000,'2015-04-23','18:30:00',1,'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',1,0),
(9,23,9,12,'2015-03-29 15:41:26','0000-00-00 00:00:00',145000,'2015-04-16','20:30:00',0,'',0,0)	;
#	TC`1gsk_deals_posts`utf8_general_ci	;
CREATE TABLE `1gsk_deals_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deal_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `deal_id` (`deal_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `1gsk_deals_posts_ibfk_1` FOREIGN KEY (`deal_id`) REFERENCES `1gsk_deals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_deals_posts_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
#	TD`1gsk_deals_posts`utf8_general_ci	;
INSERT INTO `1gsk_deals_posts` VALUES 
(4,5,9,'2015-03-29 11:55:08','\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(5,7,9,'2015-03-29 11:55:46','\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(6,6,9,'2015-03-29 11:55:53','\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(7,5,9,'2015-03-29 11:55:59','\"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(8,6,9,'2015-03-29 14:32:38','88888888888888')	;
#	TC`1gsk_migration`utf8_general_ci	;
CREATE TABLE `1gsk_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`1gsk_migration`utf8_general_ci	;
INSERT INTO `1gsk_migration` VALUES 
('m000000_000000_base',1423410897),
('m130524_201442_init',1423410904)	;
#	TC`1gsk_pages`utf8_general_ci	;
CREATE TABLE `1gsk_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8	;
#	TD`1gsk_pages`utf8_general_ci	;
INSERT INTO `1gsk_pages` VALUES 
(2,'Как работает сайт','kak-eto-rabotaet','<div class=\"kak-rabotaet-sait\">\r\n	<table class=\"kak-rabotaet-sait-tbl\">\r\n		<tr class=\"row1\">\r\n			<td class=\"cell1\"><p class=\"bold\">1) Размещает запрос на перевозку</p></td>\r\n			<td class=\"cell2\"><p class=\"bold\">2) Получает ценовые предложения</p></td>\r\n			<td class=\"cell3\"><p class=\"bold\">3) Выбирает лучшее предложение</p></td>\r\n			<td class=\"cell4\" rowspan=\"4\"><p class=\"bold\">Совершают перевозку</p></td>\r\n			<td class=\"cell5\" rowspan=\"2\">\r\n				<p class=\"italic p1\">- Оставляет отзыв о перевозчике</p>\r\n				<p class=\"italic p2\">- Повышает свой рейтинг</p>\r\n			</td>\r\n		</tr>\r\n		<tr class=\"row2\">		\r\n			<td class=\"cell1\"><p class=\"italic\">(Занимает не больше минуты)</p></td>\r\n			<td class=\"cell2\">\r\n				<p class=\"italic p1\">- Вступает в переписку с перевозчиками</p>\r\n				<p class=\"italic p2\">- Уточняет все детали будущей сделки</p>\r\n			</td>\r\n			<td class=\"cell3\">\r\n				<p class=\"italic p1\">- Получает контакты перевозчика</p>\r\n				<p class=\"italic p2\">- Торги экономят вам от 10% до 70%</p>\r\n			</td>\r\n			\r\n		</tr>\r\n		\r\n		<tr class=\"row3\">\r\n			<td class=\"cell1\"><p class=\"bold\">1) Регистрируется на сервисе</p></td>\r\n			<td class=\"cell2\"><p class=\"bold\">2) Предлагает цены и условия</p></td>\r\n			<td class=\"cell3\"><p class=\"bold\">3) Получает контакты заказчика</p></td>\r\n			\r\n			<td class=\"cell5\" rowspan=\"2\">\r\n				<p class=\"italic p1\">- Оставляет отзыв о грузодателе</p>\r\n				<p class=\"italic p2\">- Повышает свой рейтинг и уровень надежности</p>\r\n			</td>\r\n		</tr>\r\n		<tr class=\"row4\">		\r\n			<td class=\"cell1\"><p class=\"italic\">Максимально подробно заполняет профиль</p></td>\r\n			<td class=\"cell2\">\r\n				<p class=\"italic p1\">- Вступает в переписку с заказчиком</p>\r\n				<p class=\"italic p2\">- Уточняет все детали будущей сделки </p>\r\n			</td>\r\n			<td class=\"cell3\">\r\n				<p class=\"italic p1\">- Получает контакты перевозчика</p>\r\n				<p class=\"italic p2\">- Торги экономят вам от 10% до 70%</p>\r\n			</td>\r\n			\r\n		</tr>\r\n		\r\n		\r\n	</table>\r\n</div>','','',''),
(3,'Гарантии','garantii','Страница &quot;Гарантии&quot;','','',''),
(4,'Контакты','kontakty','стр.&nbsp;Контакты','','',''),
(5,'Помощь грузодателю','pomoshch-gruzodatelyu','стр.&nbsp;Помощь грузодателю','','',''),
(6,'Помощь перевозчику','pomoshch-perevozchiku','стр.&nbsp;Помощь перевозчику','','',''),
(7,'Советы при перевозке','chastye-voprosy','стр&nbsp;Советы при перевозке','','',''),
(8,'Интернет-магазинам','internet-magazinam','стр.&nbsp;Интернет-магазинам','','',''),
(9,'Система рейтинга','sistema-reitinga','стр.&nbsp;Система рейтинга','','',''),
(10,'О сервисе','o-servise','страница о сервисе','','','')	;
#	TC`1gsk_profiles`utf8_general_ci	;
CREATE TABLE `1gsk_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`1gsk_profiles`utf8_general_ci	;
INSERT INTO `1gsk_profiles` VALUES 
(1),
(2),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(21)	;
#	TC`1gsk_profiles_fields`utf8_general_ci	;
CREATE TABLE `1gsk_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` varchar(15) NOT NULL DEFAULT '0',
  `field_size_min` varchar(15) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`1gsk_transport`utf8_general_ci	;
CREATE TABLE `1gsk_transport` (
  `transport_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `carrying` varchar(10) NOT NULL,
  `length` float NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `volume` float NOT NULL,
  `body_type` varchar(255) NOT NULL,
  `loading_type` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  PRIMARY KEY (`transport_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `1gsk_transport_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`1gsk_transport`utf8_general_ci	;
INSERT INTO `1gsk_transport` VALUES 
(6,9,'BMW','1ff58fccef1c6dd12452c1298a9da795.png','100',4,5,4,0,'8888','','789878979879'),
(10,9,'Бэха 5-ка','b6c3127b24a2bfee5db2ab6778a0d5b0.png','88',5,5,5,0,'','','8979878979'),
(11,9,'Камаз 1','','',0,0,0,0,'','',''),
(12,9,'Краз 1','','',0,0,0,0,'','',''),
(13,9,'ЗИС 135','','',0,0,0,0,'','','')	;
