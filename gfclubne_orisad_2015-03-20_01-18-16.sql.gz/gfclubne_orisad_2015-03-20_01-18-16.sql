#SXD20|20010|50542|50329|2015.03.20 01:18:16|gfclubne_orisad|0|6|59|
#TA 1gsk_bids`15`16384|1gsk_bids_cargoes`7`16384|1gsk_cargoes`7`16384|1gsk_cargoes_categories`5`16384|1gsk_categories`17`16384|1gsk_pages`8`16384
#EOH

#	TC`1gsk_bids`utf8_general_ci	;
CREATE TABLE `1gsk_bids` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `date_transportation` date NOT NULL,
  `time_transportation` time NOT NULL,
  `date_unknown` tinyint(1) NOT NULL,
  `price` int(11) NOT NULL,
  `loading_town` varchar(255) NOT NULL,
  `loading_address` varchar(255) NOT NULL,
  `add_loading_unloading_town_1` varchar(255) NOT NULL,
  `add_loading_unloading_address_1` varchar(255) NOT NULL,
  `add_loading_unloading_town_2` varchar(255) NOT NULL,
  `add_loading_unloading_address_2` varchar(255) NOT NULL,
  `add_loading_unloading_town_3` varchar(255) NOT NULL,
  `add_loading_unloading_address_3` varchar(255) NOT NULL,
  `unloading_town` varchar(255) NOT NULL,
  `unloading_address` varchar(255) NOT NULL,
  PRIMARY KEY (`bid_id`),
  KEY `published` (`published`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids`utf8_general_ci	;
INSERT INTO `1gsk_bids` VALUES 
(1,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,11,'qweq','1231','','','','','','','1231','132'),
(2,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,11,'qweq','1231','','','','','','','1231','132'),
(3,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,11,'qweq','1231','','','','','','','1231','132'),
(4,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,11,'qweq','1231','','','','','','','1231','132'),
(5,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',0,0,'121122','121','','','','','','','121','21212'),
(6,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',0,3452342,'121122','121','','','','','','','121','21212'),
(7,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',0,3452342,'121122','121','','','','','','','121','21212'),
(8,0,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',0,0,'121122','121','','','','','','','1231','21212'),
(9,0,'2015-03-19 23:21:17',1,'2015-03-19','264:00:00',0,121,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(10,9,'2015-03-19 23:23:48',1,'2015-03-26','11:00:00',0,1121,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(11,9,'2015-03-19 23:46:07',1,'2015-03-19','23:10:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(12,9,'2015-03-20 00:07:24',1,'2015-03-19','13:30:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(13,9,'2015-03-20 00:17:11',1,'2015-03-26','12:45:00',0,1121,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(14,9,'2015-03-20 00:30:05',1,'2015-03-20','12:45:00',0,1234,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(15,21,'2015-03-20 00:38:37',1,'2015-03-28','23:10:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq')	;
#	TC`1gsk_bids_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_bids_cargoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bid_cagro` (`bid_id`,`cargo_id`),
  KEY `bid_id` (`bid_id`),
  KEY `cargo_id` (`cargo_id`),
  CONSTRAINT `1gsk_bids_cargoes_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_cargoes_ibfk_2` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_bids_cargoes` VALUES 
(1,12,1),
(2,12,2),
(3,13,3),
(4,13,4),
(5,14,5),
(6,14,6),
(7,15,7)	;
#	TC`1gsk_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes` (
  `cargo_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `weight` float NOT NULL,
  `unit` tinyint(1) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `porters` tinyint(1) NOT NULL,
  `lift_to_floor` tinyint(1) NOT NULL,
  `floor` smallint(2) NOT NULL,
  `length` float NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `volume` float NOT NULL,
  PRIMARY KEY (`cargo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_cargoes` VALUES 
(1,'Мебель мелкая','',12,1,'',1,0,0,0,0,0,0),
(2,'Мебель мелкая','',112,1,'',0,1,0,0,0,0,0),
(3,'Мебель мелкая','dqweqwewq',3454,1,'',0,0,0,0,0,0,0),
(4,'Техника крупная','rfrewewe',332,1,'',0,0,0,0,0,0,0),
(5,'Мебель мелкая, Техника крупная','qwdqweqwe',121,2,'',1,1,0,11,12,12,0),
(6,'Мебель мелкая wwww','sdfadq',112,1,'',0,0,0,0,0,0,0),
(7,'Мебель мелкая, Техника крупная','фвйвцй',121,1,'',1,1,0,0,0,0,0)	;
#	TC`1gsk_cargoes_categories`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cargo_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cargo_category` (`cargo_id`,`category_id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_cargoes_categories_ibfk_1` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_cargoes_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes_categories`utf8_general_ci	;
INSERT INTO `1gsk_cargoes_categories` VALUES 
(1,5,5),
(2,5,6),
(3,6,5),
(4,7,5),
(5,7,6)	;
#	TC`1gsk_categories`utf8_general_ci	;
CREATE TABLE `1gsk_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `root` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `level` tinyint(1) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` text NOT NULL,
  `meta_description` text NOT NULL,
  `category_description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`),
  KEY `level` (`level`),
  KEY `root` (`root`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8	;
#	TD`1gsk_categories`utf8_general_ci	;
INSERT INTO `1gsk_categories` VALUES 
(1,1,1,34,1,0,'ROOT !!!НЕ УДАЛЯТЬ!!!','','','',''),
(2,1,2,7,2,1,'Мебель и бытовая техника','','','',''),
(3,1,8,13,2,1,'Переезд','','','',''),
(4,1,14,15,2,1,'Перевозка пассажиров','','','',''),
(5,1,3,4,3,2,'Мебель мелкая','','','',''),
(6,1,5,6,3,2,'Техника крупная','','','',''),
(7,1,16,17,2,1,'Продукты питания','','','',''),
(8,1,18,19,2,1,'Вывоз мусора','','','',''),
(9,1,20,21,2,1,'Транспортные средства','','','',''),
(10,1,22,23,2,1,'Строительные грузы и оборудование','','','',''),
(11,1,24,25,2,1,'Наливные грузы','','','',''),
(12,1,26,27,2,1,'Сыпучие грузы','','','',''),
(13,1,28,29,2,1,'Перевозка животных','','','',''),
(14,1,30,31,2,1,'Негабарит','','','',''),
(15,1,32,33,2,1,'Прочие грузы','','','',''),
(16,1,9,10,3,3,'Переезд1','','','',''),
(17,1,11,12,3,3,'Переезд2','','','','')	;
#	TC`1gsk_pages`utf8_general_ci	;
CREATE TABLE `1gsk_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`1gsk_pages`utf8_general_ci	;
INSERT INTO `1gsk_pages` VALUES 
(2,'Как это работает','kak-eto-rabotaet','Страница &quot;Как это работает&quot;','','',''),
(3,'Гарантии','garantii','Страница &quot;Гарантии&quot;','','',''),
(4,'Контакты','kontakty','стр.&nbsp;Контакты','','',''),
(5,'Помощь грузодателю','pomoshch-gruzodatelyu','стр.&nbsp;Помощь грузодателю','','',''),
(6,'Помощь перевозчику','pomoshch-perevozchiku','стр.&nbsp;Помощь перевозчику','','',''),
(7,'Частые вопросы','chastye-voprosy','стр&nbsp;Частые вопросы','','',''),
(8,'Интернет-магазинам','internet-magazinam','стр.&nbsp;Интернет-магазинам','','',''),
(9,'Система рейтинга','sistema-reitinga','стр.&nbsp;Система рейтинга','','','')	;
