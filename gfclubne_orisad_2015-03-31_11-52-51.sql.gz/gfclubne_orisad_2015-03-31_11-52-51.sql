#SXD20|20010|50542|50329|2015.03.31 11:52:51|gfclubne_orisad|0|3|54|
#TA 1gsk_profiles`27`16384|1gsk_profiles_fields`0`16384|1gsk_users`27`16384
#EOH

#	TC`1gsk_profiles`utf8_general_ci	;
CREATE TABLE `1gsk_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8	;
#	TD`1gsk_profiles`utf8_general_ci	;
INSERT INTO `1gsk_profiles` VALUES 
(1),
(2),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(23),
(24),
(25),
(26),
(27),
(28),
(29),
(30),
(31),
(32),
(33),
(34),
(35)	;
#	TC`1gsk_profiles_fields`utf8_general_ci	;
CREATE TABLE `1gsk_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` varchar(15) NOT NULL DEFAULT '0',
  `field_size_min` varchar(15) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`1gsk_users`utf8_general_ci	;
CREATE TABLE `1gsk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `user_type` tinyint(1) DEFAULT '0' COMMENT 'грузодатель/перевозчик',
  `user_status` tinyint(1) DEFAULT '0' COMMENT 'юр.лицо / физ.лицо',
  `rating` float NOT NULL,
  `reviews_count` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8	;
#	TD`1gsk_users`utf8_general_ci	;
INSERT INTO `1gsk_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','webmaster@example.com','9a24eff8c15a6a141ece27eb6947da0f','2015-02-09 06:19:20','2015-02-14 07:10:45',1,1,0,0,0,0),
(2,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@example.com','099f825543f7850cc038b90aaff39fac','2015-02-09 06:19:20','2015-02-10 08:37:16',0,1,0,0,0,0),
(9,'alexius','2c216b1ba5e33a27eb6d3df7de7f8c36','aldegtyarev@yandex.ru','d9f2df80ade29aac196fe1dd87468438','2015-02-14 07:54:46','2015-03-28 15:11:41',0,1,2,1,0,0),
(10,'user1','b59c67bf196a4758191e42f76670ceba','user1@ya.com','801a9ee13894caf3446fbd5d0a52ef24','2015-03-05 16:33:09','0000-00-00 00:00:00',0,0,1,1,0,0),
(11,'user2','b59c67bf196a4758191e42f76670ceba','user2@mail.ru','e26df1ad8500b1365dfae6a83ef63464','2015-03-05 16:35:39','0000-00-00 00:00:00',0,0,2,2,0,0),
(12,'user3','b59c67bf196a4758191e42f76670ceba','user3@ya.com','2b2a0767317b6ca6af001e3ae3d02651','2015-03-05 16:39:47','0000-00-00 00:00:00',0,0,2,1,0,0),
(13,'user5','b59c67bf196a4758191e42f76670ceba','user5@ya.com','54c05d479a6a38e7a28556c4be78c196','2015-03-05 16:41:30','0000-00-00 00:00:00',0,0,2,2,0,0),
(14,'user6','b59c67bf196a4758191e42f76670ceba','user6@mai.ru','01b682485d1cd7adda8832c9ad2baed2','2015-03-05 17:31:44','0000-00-00 00:00:00',0,0,2,1,0,0),
(15,'user7','b59c67bf196a4758191e42f76670ceba','user7@ya.com','40f98ac2f1dbec41d2cfcd86ab51da99','2015-03-05 17:37:36','0000-00-00 00:00:00',0,0,1,1,0,0),
(16,'user8','b59c67bf196a4758191e42f76670ceba','usr8@meil.ru','829bb32a06bf2487f35cdfba1ed6cfeb','2015-03-05 17:40:22','0000-00-00 00:00:00',0,0,2,2,0,0),
(17,'proverka','6c14da109e294d1e8155be8aa4b1ce8e','tribe@li.ru','4d3983175fafb40f2c79b82c42a0fd36','2015-03-13 15:21:39','0000-00-00 00:00:00',0,0,1,1,0,0),
(18,'proverka3','6c14da109e294d1e8155be8aa4b1ce8e','design@farba.pro','1e06321dd4dfb1eb2fbfd1a8cec81e6e','2015-03-13 15:22:25','0000-00-00 00:00:00',0,0,1,1,0,0),
(19,'sjock','ca94efe2a58c27168edf3d35102dbb6d','sjock@yandex.ru','f7634278fdda2791206a7c779472fb61','2015-03-13 15:26:33','0000-00-00 00:00:00',0,0,2,1,0,0),
(20,'proverka4','e10adc3949ba59abbe56e057f20f883e','trribe@yandex.ru','f826cd3b3d087481929ea01c820d3fe6','2015-03-13 15:27:11','0000-00-00 00:00:00',0,0,2,1,0,0),
(23,'aad1','2c216b1ba5e33a27eb6d3df7de7f8c36','aldegtyarev1980@mail.ru','98be76455848384f6fe30b93d70c5113','2015-03-20 01:33:45','0000-00-00 00:00:00',0,0,1,1,0,0),
(24,'Cthtsdfsdfs','5f375174f2c673c1d3f4f9939b1b5974','vv@yandex.ru','4be334fca6918dfd2c2c61efbd788fe7','2015-03-20 01:44:19','0000-00-00 00:00:00',0,0,1,1,0,0),
(25,'sergei','d4ccc100b7d5601e0cad4d962c422d29','a2123-asd@yandex.ru','d05ba43aeb45699064c9184de30c781e','2015-03-21 18:25:23','0000-00-00 00:00:00',0,0,1,1,0,0),
(26,'kirill','70d5ea0e3392d3f3ff9a4c849ea908b5','g5-u8@yandex.ru','a7e2756a92bb33db36e73e94e4edd590','2015-03-21 18:33:45','0000-00-00 00:00:00',0,0,1,1,0,0),
(27,'sergei12','5031c36a160965740f235433f5c25566','as-zx3@yandex.ru','1f07c4065ddc3ae6ea36b7ee03ed9240','2015-03-21 18:37:56','0000-00-00 00:00:00',0,0,1,1,0,0),
(28,'ivan','58e2dd250cc204d8f5dc13c84bd24db7','as-d34@yandex.ru','082ce6ddfbc3bae5ff3d3e9d907ee6d2','2015-03-23 10:47:19','0000-00-00 00:00:00',0,0,1,1,0,0),
(29,'petr','714bb0cad0eaef1b8fda2a38447d5d50','sd-3a@yandex.ru','0d454859e993d433edb0f72b26f8174e','2015-03-25 00:45:06','0000-00-00 00:00:00',0,0,1,1,0,0),
(30,'artem88','6b65c266e68cd0a856fe954bf2fbdca4','f4.sd@yandex.ru','c597951bb772a8a37e8889c093a6cd2a','2015-03-25 20:19:17','0000-00-00 00:00:00',0,0,1,1,0,0),
(31,'artem881','6b65c266e68cd0a856fe954bf2fbdca4','a5.yv@yandex.ru','94ada8ae63e9ea35d3e8eb56dd7df22c','2015-03-25 20:19:55','0000-00-00 00:00:00',0,0,1,1,0,0),
(32,'artem8899','6b65c266e68cd0a856fe954bf2fbdca4','fv.a42014@yandex.ru','08c9123f6c5122d2e281e7cbf5c8b4a5','2015-03-25 20:20:34','0000-00-00 00:00:00',0,0,1,1,0,0),
(33,'ottodix333','6b65c266e68cd0a856fe954bf2fbdca4','ds4ddv.34@yandex.ru','d486d47e4c7d68469803e49e3385aa19','2015-03-25 20:21:28','0000-00-00 00:00:00',0,0,1,1,0,0),
(34,'ottodix1','6b65c266e68cd0a856fe954bf2fbdca4','r6f.e@yandex.ru','cd0e619119dd6ca9c346a815f7cde70b','2015-03-25 20:22:38','0000-00-00 00:00:00',0,0,2,1,0,0),
(35,'artem8811','6b65c266e68cd0a856fe954bf2fbdca4','ya.kovil@yandex.by','79150e4efac91d4f7c8378b5c5c4ffe9','2015-03-27 00:26:23','0000-00-00 00:00:00',0,0,2,2,0,0)	;
