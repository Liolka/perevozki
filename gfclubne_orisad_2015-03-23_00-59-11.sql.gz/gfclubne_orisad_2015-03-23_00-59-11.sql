#SXD20|20010|50542|50329|2015.03.23 00:59:11|gfclubne_orisad|0|5|48|
#TA 1gsk_bids`11`16384|1gsk_bids_cargoes`13`16384|1gsk_cargoes`13`16384|1gsk_cargoes_categories`11`16384|1gsk_deals`0`16384
#EOH

#	TC`1gsk_bids`utf8_general_ci	;
CREATE TABLE `1gsk_bids` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `date_transportation` date NOT NULL,
  `time_transportation` time NOT NULL,
  `date_unknown` tinyint(1) NOT NULL,
  `price` int(11) NOT NULL,
  `loading_town` varchar(255) NOT NULL,
  `loading_address` varchar(255) NOT NULL,
  `add_loading_unloading_town_1` varchar(255) NOT NULL,
  `add_loading_unloading_address_1` varchar(255) NOT NULL,
  `add_loading_unloading_town_2` varchar(255) NOT NULL,
  `add_loading_unloading_address_2` varchar(255) NOT NULL,
  `add_loading_unloading_town_3` varchar(255) NOT NULL,
  `add_loading_unloading_address_3` varchar(255) NOT NULL,
  `unloading_town` varchar(255) NOT NULL,
  `unloading_address` varchar(255) NOT NULL,
  PRIMARY KEY (`bid_id`),
  KEY `published` (`published`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_bids_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids`utf8_general_ci	;
INSERT INTO `1gsk_bids` VALUES 
(1,9,2,'0000-00-00 00:00:00',0,'0000-00-00','00:00:00',1,11,'qweq','1231','','','','','','','1231','132'),
(11,9,2,'2015-03-19 23:46:07',1,'2015-03-19','23:10:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(12,9,2,'2015-03-20 00:07:24',1,'2015-03-19','13:30:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(13,9,2,'2015-03-20 00:17:11',1,'2015-03-26','12:45:00',0,1121,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(14,9,2,'2015-03-20 00:30:05',1,'2015-03-20','12:45:00',0,1234,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(15,21,2,'2015-03-20 00:38:37',1,'2015-03-28','23:10:00',0,1211,'qqqq','qqqq','','','','','','','qqqq','qqqq'),
(16,9,2,'2015-03-20 16:07:51',1,'0000-00-00','00:00:00',0,0,'121122','121','','','','','','','1231','21212'),
(17,9,2,'2015-03-20 19:12:52',1,'2015-03-27','16:00:00',0,230000,'Гомель','ул. Советская 10','','','','','','','Гомель','ул. Советская 110'),
(18,9,2,'2015-03-21 00:19:12',1,'2015-03-27','23:10:00',0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(20,9,1,'2015-03-21 23:17:02',1,'2015-03-04','23:10:00',0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21'),
(21,9,2,'2015-03-21 23:20:42',1,'2015-03-13','12:45:00',0,250000,'Гомель','Советская 23','','','','','','','Гомель','Космонавтов 21')	;
#	TC`1gsk_bids_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_bids_cargoes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `cargo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bid_cagro` (`bid_id`,`cargo_id`),
  KEY `bid_id` (`bid_id`),
  KEY `cargo_id` (`cargo_id`),
  CONSTRAINT `1gsk_bids_cargoes_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_bids_cargoes_ibfk_2` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`1gsk_bids_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_bids_cargoes` VALUES 
(1,12,1),
(2,12,2),
(3,13,3),
(4,13,4),
(5,14,5),
(6,14,6),
(7,15,7),
(8,16,8),
(9,17,9),
(10,18,10),
(11,18,11),
(12,20,12),
(13,21,13)	;
#	TC`1gsk_cargoes`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes` (
  `cargo_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `weight` float NOT NULL,
  `unit` tinyint(1) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `porters` tinyint(1) NOT NULL,
  `lift_to_floor` tinyint(1) NOT NULL,
  `floor` smallint(2) NOT NULL,
  `length` float NOT NULL,
  `width` float NOT NULL,
  `height` float NOT NULL,
  `volume` float NOT NULL,
  PRIMARY KEY (`cargo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes`utf8_general_ci	;
INSERT INTO `1gsk_cargoes` VALUES 
(1,'Мебель мелкая','',12,1,'',1,0,0,0,0,0,0),
(2,'Мебель мелкая','',112,1,'',0,1,0,0,0,0,0),
(3,'Мебель мелкая','dqweqwewq',3454,1,'',0,0,0,0,0,0,0),
(4,'Техника крупная','rfrewewe',332,1,'',0,0,0,0,0,0,0),
(5,'Мебель мелкая, Техника крупная','qwdqweqwe',121,2,'',1,1,0,11,12,12,0),
(6,'Мебель мелкая wwww','sdfadq',112,1,'',0,0,0,0,0,0,0),
(7,'Мебель мелкая, Техника крупная','фвйвцй',121,1,'',1,1,0,0,0,0,0),
(8,'','',0,0,'',0,0,0,0,0,0,0),
(9,'Мебель мелкая','мой коммент к грузу',50,1,'',0,0,0,3,2,5,30),
(10,'Мебель мелкая','12312321',121,1,'',0,0,0,0,0,0,0),
(11,'Техника крупная','312313123',12,1,'',1,0,0,0,0,0,0),
(12,'Мебель мелкая, Техника крупная','',121,1,'',0,0,0,0,0,0,0),
(13,'Мебель мелкая','',0,1,'',0,0,0,0,0,0,0)	;
#	TC`1gsk_cargoes_categories`utf8_general_ci	;
CREATE TABLE `1gsk_cargoes_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cargo_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cargo_category` (`cargo_id`,`category_id`),
  KEY `cargo_id` (`cargo_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `1gsk_cargoes_categories_ibfk_1` FOREIGN KEY (`cargo_id`) REFERENCES `1gsk_cargoes` (`cargo_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_cargoes_categories_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `1gsk_categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8	;
#	TD`1gsk_cargoes_categories`utf8_general_ci	;
INSERT INTO `1gsk_cargoes_categories` VALUES 
(1,5,5),
(2,5,6),
(3,6,5),
(4,7,5),
(5,7,6),
(6,9,5),
(7,10,5),
(8,11,6),
(9,12,5),
(10,12,6),
(11,13,5)	;
#	TC`1gsk_deals`utf8_general_ci	;
CREATE TABLE `1gsk_deals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bid_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `carrier_comment` text NOT NULL,
  `customer_comment` text NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  `rejected` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bid_id` (`bid_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `1gsk_deals_ibfk_1` FOREIGN KEY (`bid_id`) REFERENCES `1gsk_bids` (`bid_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `1gsk_deals_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
