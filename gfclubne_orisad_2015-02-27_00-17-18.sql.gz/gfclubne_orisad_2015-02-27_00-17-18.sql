#SXD20|20010|50542|50329|2015.02.27 00:17:18|gfclubne_orisad|0|6|11|
#TA 1gsk_migration`2`16384|1gsk_pages`2`16384|1gsk_profiles`3`16384|1gsk_profiles_fields`0`16384|1gsk_users`3`16384|1gsk_users1`1`16384
#EOH

#	TC`1gsk_migration`utf8_general_ci	;
CREATE TABLE `1gsk_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TD`1gsk_migration`utf8_general_ci	;
INSERT INTO `1gsk_migration` VALUES 
('m000000_000000_base',1423410897),
('m130524_201442_init',1423410904)	;
#	TC`1gsk_pages`utf8_general_ci	;
CREATE TABLE `1gsk_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `meta_title` varchar(255) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`1gsk_pages`utf8_general_ci	;
INSERT INTO `1gsk_pages` VALUES 
(2,'О нас','o-nas','<p>S-Turbo.BY –&nbsp; <strong>уникальный</strong> на белорусском профессиональном пространстве проект с перспективой роста до крупнейшего в РБ портала специалистов и любителей автотюнинга. В отличие от других подобных тюнинг – магазинов, S-Turbo.BY это беспрецедентный проект, который объединяет в себе сразу несколько видов деятельности.</p>\r\n<p><strong>•&nbsp;&nbsp; &nbsp;Интернет - магазин тюнинга</strong><br>Это основная и самая важная часть нашей работы. Мы продаем автоаксессуары для тюнинга от лучших мировых&nbsp; производителей и с каждым днем наш ассортимент неуклонно растет. Наша цель -&nbsp; обеспечить достойный выбор товаров по каждому наименованию. Поскольку магазин работает без посредников, цены у нас самые лояльные. Мы работаем по всей Беларуси, поэтому нет необходимости искать <strong>другие тюнинг - магазины&nbsp; в Минске</strong> или другом городе! Товар будет доставлен нашим курьером прямо к порогу вашего дома в любую точку страны.<br>Также вы сможете посмотреть какие компании оказывают <a href=\"/companyes.html?regions=&amp;city=&amp;comments=&amp;section=48%2C49%2C50%2C51%2C52%2C53%2C54%2C55%2C56%2C57%2C58%2C59%2C60%2C61%2C62%2C63%2C64&amp;section_name=%D0%A1%D0%A2%D0%9E#sideLeft\">услуги по ремонту авто</a>.</p>\r\n<p><strong>•&nbsp;&nbsp; &nbsp; Каталог автокомпаний<br>Тюнинг - магазин</strong> S-Turbo.BY это еще и отличная рекламная площадка для успешного развития вашего бизнеса. Компаниям, оказывающим различные автомобильные услуги, мы предлагаем ярко заявить о себе на нашем сайте и в группе Вконтакте. Подробнее о возможностях S-Turbo читайте <a target=\"_blank\" href=\"/dobavit-svoyu-uslugu.html\"><strong>здесь</strong></a>.</p>\r\n<p><strong>•&nbsp;&nbsp; &nbsp; Клуб/форум</strong><br>Ну и наконец, S-Turbo.BY это большое интернет-сообщество любителей тюнинга автомобилей. На базе портала действует клуб и форум, где обсуждаются&nbsp; самые интересные и актуальные автотемы. Стать членом нашего дружного клуба может каждый, пройдя предварительную регистрацию. Участники клуба получают возможность задавать на форуме вопросы профессионалам в сфере тюнинга, оставлять свои отзывы об услугах компаний, участвовать в закрытых встречах клуба, получать приятные скидки на товары и многие&nbsp; другие бонусы!</p>\r\n<p><strong>Будем рады видеть вас в числе наших клиентов и партнеров!</strong></p>','','',''),
(3,'tot 1231','tot-1231','<img alt=\"\" src=\"/uploads/images/1346389588_02.jpg\" style=\"height:150px; width:200px\" />aeqweqw<br />\r\nwqwqasd<br />\r\nasdasdasd','','','')	;
#	TC`1gsk_profiles`utf8_general_ci	;
CREATE TABLE `1gsk_profiles` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profile_id` FOREIGN KEY (`user_id`) REFERENCES `1gsk_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`1gsk_profiles`utf8_general_ci	;
INSERT INTO `1gsk_profiles` VALUES 
(1),
(2),
(9)	;
#	TC`1gsk_profiles_fields`utf8_general_ci	;
CREATE TABLE `1gsk_profiles_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `varname` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `field_size` varchar(15) NOT NULL DEFAULT '0',
  `field_size_min` varchar(15) NOT NULL DEFAULT '0',
  `required` int(1) NOT NULL DEFAULT '0',
  `match` varchar(255) NOT NULL DEFAULT '',
  `range` varchar(255) NOT NULL DEFAULT '',
  `error_message` varchar(255) NOT NULL DEFAULT '',
  `other_validator` varchar(5000) NOT NULL DEFAULT '',
  `default` varchar(255) NOT NULL DEFAULT '',
  `widget` varchar(255) NOT NULL DEFAULT '',
  `widgetparams` varchar(5000) NOT NULL DEFAULT '',
  `position` int(3) NOT NULL DEFAULT '0',
  `visible` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `varname` (`varname`,`widget`,`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8	;
#	TC`1gsk_users`utf8_general_ci	;
CREATE TABLE `1gsk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `activkey` varchar(128) NOT NULL DEFAULT '',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `user_type` tinyint(1) DEFAULT '0' COMMENT 'грузодатель/перевозчик',
  `user_status` tinyint(1) DEFAULT '0' COMMENT 'юр.лицо / физ.лицо',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`),
  KEY `superuser` (`superuser`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8	;
#	TD`1gsk_users`utf8_general_ci	;
INSERT INTO `1gsk_users` VALUES 
(1,'admin','21232f297a57a5a743894a0e4a801fc3','webmaster@example.com','9a24eff8c15a6a141ece27eb6947da0f','2015-02-09 07:19:20','2015-02-14 08:10:45',1,1,0,0),
(2,'demo','fe01ce2a7fbac8fafaed7c982a04e229','demo@example.com','099f825543f7850cc038b90aaff39fac','2015-02-09 07:19:20','2015-02-10 09:37:16',0,1,0,0),
(9,'alexius','2c216b1ba5e33a27eb6d3df7de7f8c36','aldegtyarev@yandex.ru','d9f2df80ade29aac196fe1dd87468438','2015-02-14 08:54:46','2015-02-26 22:12:46',0,1,2,1)	;
#	TC`1gsk_users1`utf8_unicode_ci	;
CREATE TABLE `1gsk_users1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci	;
#	TD`1gsk_users1`utf8_unicode_ci	;
INSERT INTO `1gsk_users1` VALUES 
(1,'admin','j-NT1lxHguMH1KQU_DegytBsqo2FTW0u','',\N,'aad@site.com',1,1423427052,1423427052)	;
